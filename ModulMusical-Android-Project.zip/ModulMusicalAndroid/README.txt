MODUL MUSICAL - Android Studio project source

This is an Android WebView wrapper for the supplied ModulMusical-Pink.html file.
It is source code, not a prebuilt APK.

To build:
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync and install any requested Android SDK platform.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android phone.

Package: com.modulmusical.app
Min Android: 6.0 (API 23)
